<?php

namespace Crysoft\MpesaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CrysoftMpesaBundle extends Bundle
{

}
