<?php
/*********************************************************************************
 * Developed by Maxx Ng'ang'a
 * (C) 2017 Crysoft Dynamics Ltd
 * Karbon V 2.1
 * User: Maxx
 * Date: 6/7/2017
 * Time: 2:26 PM
 ********************************************************************************/

namespace Crysoft\MpesaBundle\Exceptions;


class TransactionException extends \Exception
{

}